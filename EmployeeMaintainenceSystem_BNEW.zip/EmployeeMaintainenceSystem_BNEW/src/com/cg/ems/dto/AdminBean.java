package com.cg.ems.dto;

import java.sql.Date;

public class AdminBean {
	private String emp_id;
	private String first_name;
	private String last_name;
	private Date date_birth;
	private Date date_joining;
	private int dept_id;
	private String grade;
	private String designation;
	private int basic_pay;
	private String gender;
	private String marital_status;
	private String home_address;
	private String contact_num;
	
	
	
	
	public AdminBean() {
		super();
	}
	
	public AdminBean(String emp_id, String first_name, String last_name,
			Date date_birth, Date date_joining, int dept_id, String grade,
			String designation, int basic_pay, String gender,
			String marital_status, String home_address, String contact_num) {
		super();
		this.emp_id = emp_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.date_birth = date_birth;
		this.date_joining = date_joining;
		this.dept_id = dept_id;
		this.grade = grade;
		this.designation = designation;
		this.basic_pay = basic_pay;
		this.gender = gender;
		this.marital_status = marital_status;
		this.home_address = home_address;
		this.contact_num = contact_num;
	}

	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public Date getDate_birth() {
		return date_birth;
	}
	public void setDate_birth(Date date_birth) {
		this.date_birth = date_birth;
	}
	public Date getDate_joining() {
		return date_joining;
	}
	public void setDate_joining(Date date_joining) {
		this.date_joining = date_joining;
	}
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getBasic_pay() {
		return basic_pay;
	}
	public void setBasic_pay(int basic_pay) {
		this.basic_pay = basic_pay;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	public String getHome_address() {
		return home_address;
	}
	public void setHome_address(String home_address) {
		this.home_address = home_address;
	}
	public String getContact_num() {
		return contact_num;
	}
	public void setContact_num(String contact_num) {
		this.contact_num = contact_num;
	}
	@Override
	public String toString() {
		return "AdminBean [emp_id=" + emp_id + ", first_name=" + first_name
				+ ", last_name=" + last_name + ", date_birth=" + date_birth
				+ ", date_joining=" + date_joining + ", dept_id=" + dept_id
				+ ", grade=" + grade + ", designation=" + designation
				+ ", basic_pay=" + basic_pay + ", gender=" + gender
				+ ", marital_status=" + marital_status + ", home_address="
				+ home_address + ", contact_num=" + contact_num + "]";
	}
	
	

}
