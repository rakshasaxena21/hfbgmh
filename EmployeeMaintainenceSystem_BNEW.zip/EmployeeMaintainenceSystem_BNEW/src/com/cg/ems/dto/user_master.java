package com.cg.ems.dto;

public class user_master {
	
	
	private String userId;
	private String name;
	private String password;
	private String usertype;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	
	
	public user_master(String userId, String name, String password,
			String usertype) {
		super();
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.usertype = usertype;
	}
	
	
	
	public user_master() {
		super();
	}
	
	
	@Override
	public String toString() {
		return "user_master [userId=" + userId + ", name=" + name
				+ ", password=" + password + ", usertype=" + usertype + "]";
	}
	
	
	
	
	
}