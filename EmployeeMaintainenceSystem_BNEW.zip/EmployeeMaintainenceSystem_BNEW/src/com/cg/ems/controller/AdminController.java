package com.cg.ems.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ems.dto.AdminBean;
import com.cg.ems.exception.AdminException;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.IAdminService;
import com.cg.ems.util.DBUtil;




@WebServlet("/admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		IAdminService service = new AdminServiceImpl();
		
		switch (action) {
		
		
		//ADD
		case "add":
		
			
			
			//Date birth	
			String date_birth = request.getParameter("date_birth");
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			  
			 Date date=null;
			 try {
				date=formatter.parse(date_birth);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 java.sql.Date actDate = new java.sql.Date(date.getTime());	
			
			 
			 
			 
			 // JOING
			 String date_joining = request.getParameter("date_joining");
				
				SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MM-yyyy");
				  
				 Date date1=null;
				 try {
					date1=formatter.parse(date_joining);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 java.sql.Date joinDate = new java.sql.Date(date.getTime());
				 
			 AdminBean admin = new AdminBean();	 
			 admin.setFirst_name(request.getParameter("first_name"));
			 admin.setLast_name(request.getParameter("last_name"));
			 admin.setDate_birth(actDate);
			 admin.setDate_joining(joinDate);
			 admin.setDept_id(Integer.parseInt(request.getParameter("dept_id")));
			 admin.setGrade(request.getParameter("grade"));
			 admin.setDesignation(request.getParameter("designation"));
			 admin.setBasic_pay(Integer.parseInt(request.getParameter("basic_pay")));
			 admin.setGender(request.getParameter("gender"));
			 admin.setMarital_status(request.getParameter("marital_status"));
			 admin.setHome_address(request.getParameter("home_address"));
			 admin.setContact_num(request.getParameter("contact_num"));
			 
		     
			  
					  try {
						String id=service.add(admin);
						admin.setEmp_id(id);
						
					} catch (AdminException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						request.getSession().setAttribute("error", e.getMessage());
					}
					  request.getSession().setAttribute("empl",admin);
					  RequestDispatcher view=request.getRequestDispatcher("success.jsp");
					  view.forward(request, response);
					  
		return;
		
		
		
		
		//SHOW
		case "show":
			try {
				List<AdminBean> ad2=service.showAll();
				request.getSession().setAttribute("empList",ad2);
				request.getSession().getAttribute("show.jsp");
				System.out.println("reached heree also");
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			RequestDispatcher view2=request.getRequestDispatcher("show.jsp");
			view2.forward(request, response); 
			return;
			
			
			
		//EDIT	
		case "edit":
			HttpSession session = request.getSession();
			String emp_id = request.getParameter("emp_id");
			System.out.println(emp_id);
		  session.setAttribute("empId", emp_id);
			System.out.println(emp_id);
			String error;
			if(emp_id !=null){
				try {
					AdminBean ad=service.search(emp_id);
					System.out.println(ad);
					request.setAttribute("emp",ad);
					System.out.println("and jheer also");
					RequestDispatcher view3=request.getRequestDispatcher("editemployee.jsp");
					view3.forward(request, response);
					
				} catch (AdminException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error" +e.getMessage());
				}
			}else{
					error="Please select employee to edit";
					response.sendRedirect("add.jsp?error="+error);	
					
				}
			return;
			
			
			
			//UPDATE
		case "update":
			session = request.getSession(false);
            String dateBirth = request.getParameter("date_birth");
			
			SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MM-yyyy");
			  
			 Date date2=null;
			 try {
				date2=formatter2.parse(dateBirth);
			} catch (ParseException e) {
				System.out.println("ye galat hai");
				e.printStackTrace();
			}	 
			 java.sql.Date actDate2 = new java.sql.Date(date2.getTime());
			 
			 
			 
			 
			 String JoiningDate = request.getParameter("date_joining");
				
				SimpleDateFormat formatter4 = new SimpleDateFormat("dd-MM-yyyy");
				  
				 Date date3=null;
				 try {
					date3=formatter4.parse(JoiningDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 java.sql.Date joinDate2 = new java.sql.Date(date3.getTime());
			
			AdminBean a=new AdminBean();
		
			a.setEmp_id((String)session.getAttribute("empId"));
			System.out.println("t1");
			a.setFirst_name(request.getParameter("first_name"));
			System.out.println("t2");
			a.setLast_name(request.getParameter("last_name"));
			System.out.println("t3");
			a.setDate_birth(actDate2);
			System.out.println("t4");
			a.setDate_joining(joinDate2);
			System.out.println("t5");
			a.setDept_id(Integer.parseInt(request.getParameter("dept_id")));
			System.out.println("t6");
			a.setGrade(request.getParameter("grade"));
			System.out.println("t7");
			a.setDesignation(request.getParameter("designation"));
			System.out.println("t8");
			a.setBasic_pay(Integer.parseInt(request.getParameter("basic_pay")));
			System.out.println("t9");
			a.setGender(request.getParameter("gender"));
			System.out.println("t10");
			a.setMarital_status(request.getParameter("marital_status"));
			System.out.println("t11");
			a.setHome_address(request.getParameter("home_address"));
			System.out.println("t12");
			a.setContact_num(request.getParameter("contact_num"));
			System.out.println("t13");
			System.out.println(a);
			try {
				service.update(a);
				request.setAttribute("message", "Record Updated!");
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.setAttribute("error", "Unable to Update" +e.getMessage());
				
			}
			RequestDispatcher view4=request.getRequestDispatcher("show.jsp");
			view4.forward(request, response);
			
	
			return;
			
			//SEARCH
			
		case "search":
			HttpSession session1 = request.getSession();
			String id = request.getParameter("emp_id");
			System.out.println(id);
		  session1.setAttribute("empId", id);
			System.out.println(id);
			//String error1;
			if(id !=null){
				try {
					AdminBean ad3=service.search(id);
					System.out.println(ad3);
					request.setAttribute("emp",ad3);
					System.out.println("here it comes");
					System.out.println(ad3);
					RequestDispatcher view5=request.getRequestDispatcher("searchemp.jsp");
					view5.forward(request, response);
					
				} catch (AdminException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error" +e.getMessage());
				}
			}else{
					//error1="Please select employee to search";
					response.sendRedirect("admin.jsp");	
					
				}
			return;
		
		
		
	case "form":
	    String id1=request.getParameter("userId");
	    System.out.println("t1");
	    String pass=request.getParameter("password");
	    System.out.println("t2");
	    Connection conn;
		try {
			conn = DBUtil.getConnection();
			 PreparedStatement pst=conn.prepareStatement("Select usertype,name from user_master where userId = ? and password = ? "); 
			    pst.setString(1,id1); 
			    pst.setString(2,pass);
			    System.out.println("t3");
			    ResultSet rst=pst.executeQuery(); 
			    System.out.println("t4");
			    if(rst.next()) 
			    { 
			    String type=rst.getString("usertype"); 
			    System.out.println("t5");
			    System.out.println("user type="+type);
			    System.out.println("t6");
			    if("admin".equals(type)) 
			    { 
			    System.out.println(type); 
			    response.sendRedirect("admin.jsp"); 
			    } 
			    if("employee".equals(type)) 
			    { 
			    	System.out.println("tarunnnnnnn");
			    System.out.println(type); 
			    response.sendRedirect("employee.jsp"); 
			    } 
			   
			    }
		} catch (NamingException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    break;
	
		}	
		}
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
