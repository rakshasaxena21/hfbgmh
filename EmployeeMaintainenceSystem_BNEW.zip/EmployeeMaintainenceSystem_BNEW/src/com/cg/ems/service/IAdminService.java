package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dto.AdminBean;
import com.cg.ems.dto.user_master;
import com.cg.ems.exception.AdminException;




public interface IAdminService {
	user_master compare(String id) ;
	public String add(AdminBean admin) throws AdminException;
	 List<AdminBean> showAll() throws AdminException;
	 void update(AdminBean e)throws AdminException;
	AdminBean search(String emp_id)throws AdminException;
	

}
